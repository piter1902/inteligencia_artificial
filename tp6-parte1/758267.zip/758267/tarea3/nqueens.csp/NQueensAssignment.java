package aima.gui.nqueens.csp;

import aima.core.search.csp.Assignment;

public class NQueensAssignment extends Assignment {
	public NQueensAssignment() {
		super();
	}
}
